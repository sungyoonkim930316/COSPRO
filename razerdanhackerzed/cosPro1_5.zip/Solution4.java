package cosPro1_5;
class Solution4 {
    public String solution(int number) {
        String answer = "";

        int[] numberCount = new int[10];
        while(number > 0) {
            numberCount[number % 10]++;
            number /= 10;
        }

        for(int i = 0; i < 10; i++)
            if(numberCount[i] != 0)
                answer += (String.valueOf(i) + String.valueOf(numberCount[i]));
        
        return answer;
    }

    public static void main(String[] args) {
    	Solution4 sol = new Solution4();
    	int number1 = 2433;
    	String ret1 = sol.solution(number1);
    	System.out.println("Solution: return value of the method is " + ret1 + " .");

    	int number2 = 662244;
    	String ret2 = sol.solution(number2);
    	System.out.println("Solution: return value of the method is " + ret2 + " .");
    }
}