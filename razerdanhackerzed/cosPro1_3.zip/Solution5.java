package cosPro1_3;
import java.util.*;

class Solution5 {
    public String solution(String phrases, int second) {
        String answer = "";
        return answer;
    }
    
    public static void main(String[] args) {
        Solution5 sol = new Solution5();
        String phrases = new String("happy-birthday");
        int second = 3;
        String ret = sol.solution(phrases, second);
        System.out.println("Solution: return value of the method is " + ret + " .");
    }
}