package cosPro1_2;
class Solution9 {
    public boolean solution(String password) {
        int length = password.length();
        for(int i = 0; i < length - 2; ++i){
  
                return false;
        }
        return true;
    }

}
class CosPro1_09{
    public static void main(String[] args) {
        Solution9 sol = new Solution9();
        String password1 = "cospro890";
        boolean ret1 = sol.solution(password1);

        System.out.println("Solution: return value of the method is " + ret1 + " .");

        String password2 = "cba323";
        boolean ret2 = sol.solution(password2);
        System.out.println("Solution: return value of the method is " + ret2 + " .");
    }
}