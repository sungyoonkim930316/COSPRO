package cosPro04;
import java.util.*;

class Solution {
    public int solution(int[] scores, int cutline) {
        int answer = 0;
        return answer;
    }
}

class CosPro2_4_10{ 
    public static void main(String[] args) {
        Solution sol = new Solution();
        int[] scores = {80, 90, 55, 60, 59};
        int cutline = 60;
        int ret = sol.solution(scores, cutline);

        System.out.println("solution " + ret + " .");
    }
}