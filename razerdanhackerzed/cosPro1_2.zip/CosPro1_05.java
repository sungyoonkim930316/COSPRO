package cosPro1_2;
import java.util.*;

class Solution5 {
    public int solution(int[] arr) {
        int answer = 0;
        return answer;
    }
}
class CosPro1_05{
    public static void main(String[] args) {
        Solution5 sol = new Solution5();
        int[] arr = {3, 1, 2, 4, 5, 1, 2, 2, 3, 4};
        int ret = sol.solution(arr);

        System.out.println("Solution: return value of the method is " + ret + " .");
    }
}