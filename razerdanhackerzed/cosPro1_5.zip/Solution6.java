package cosPro1_5;
import java.util.*;

class Solution6 {	
    public String solution(String s1, String s2, int p, int q) {
        String answer = "";
        return answer;
    }
    
    public static void main(String[] args) {
    	Solution6 sol = new Solution6();
    	String s1 = new String("112001");
        String s2 = new String("12010");
        int p = 3;
        int q = 8;
    	String ret = sol.solution(s1, s2, p, q);
    	System.out.println("Solution: return value of the method is " + ret + " .");
   }
}