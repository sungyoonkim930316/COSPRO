package cosPro04;
class Solution4 {
    public int solution(int[] classes, int m) {
        int answer = 0;
        for(int i=0; i<classes.length; i++) {
           // answer += classes[i] @@@ m;
            //if (classes[i] @@@ m != 0)
            //    answer++;
        }
        return answer;
    }
}
class CosPro2_4_04{ 
    public static void main(String[] args) {
        Solution4 sol = new Solution4();
        int[] classes = {80, 45, 33, 20};
        int m = 30;
        int ret = sol.solution(classes, m);
        
        System.out.println("solution " + ret + "");
    }
}