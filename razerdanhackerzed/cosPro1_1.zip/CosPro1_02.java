package cosPro1_1;
// You may use import as below.
//import java.util.*;

class Solution2 {
    public int solution(int n) {
        // Write code here.
        int answer = 0;
        return answer;
    }
}
class CosPro1_02{
    // The following is main method to output testcase.
    public static void main(String[] args) {
        Solution2 sol = new Solution2();
        int n1 = 3;
        int ret1 = sol.solution(n1);

        
        // Press Run button to receive output. 
        System.out.println("Solution: return value of the method is " + ret1 + " .");
        
        int n2 = 2;
        int ret2 = sol.solution(n2);
        
        // Press Run button to receive output. 
        System.out.println("Solution: return value of the method is " + ret2 + " .");
    }
}