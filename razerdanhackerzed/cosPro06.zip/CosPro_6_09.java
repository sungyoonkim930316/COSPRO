package cosPro06;
 class Solution9 {
	public int solution(int[] socks) {
		int answer = 0;

		int[] count = new int[10];
		for(int i = 0; i < socks.length; i++)
			count[socks[i]]++;

		for(int i = 0; i < 10; i++)
			answer += (count[i] % 2);

		return answer;
	}
}

class CosPro_6_09{
	public static void main(String[] args) {
		Solution9 sol = new Solution9();
		int[] socks = {1, 2, 1, 3, 2, 1};
		int ret = sol.solution(socks);
		System.out.println("solution  " + ret + ".");
	}
}