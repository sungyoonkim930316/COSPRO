package cosPro05;
class Solution3 {
    public int solution(int speed, int[] cars) {
        int answer = 0;
        
        for(int i = 0; i < cars.length; i++) {
            if(cars[i] >= speed * 11 / 10 && cars[i] < speed * 12 / 10)
                answer += 3;
          //  else if(cars[i] >= @@@ && cars[i] < @@@)
                answer += 5;
         //   else if(cars[i] >= @@@)
                answer += 7;
        }
        
        return answer;
    }

}
class CosPro05_03{
    public static void main(String[] args) {
        Solution3 sol = new Solution3();
        int speed = 100;
        int[] cars = {110, 98, 125, 148, 120, 112, 89};
        int ret = sol.solution(speed, cars);
        
        System.out.println("solution " + ret + " .");

    }
}