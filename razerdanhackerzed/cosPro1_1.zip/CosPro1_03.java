package cosPro1_1;
// You may use import as below.
//import java.util.*;

class Solution3 {
    public int solution(String pos) {
        // Write code here.
        int answer = 0;
        return answer;
    }
}
class CosPro1_03{
    // The following is main method to output testcase.
    public static void main(String[] args) {
        Solution3 sol = new Solution3();
        String pos = "A7";
        int ret = sol.solution(pos);

        // Press Run button to receive output. 
        System.out.println("Solution: return value of the method is " + ret + " .");
    }
}