package cosPro1_4;
import java.util.*;

class Solution8 {
    public int solution(int[] card, int n) {
        int answer = 0;
        return answer;
    }
    
    public static void main(String[] args) {
        Solution8 sol = new Solution8();
        int card1[] = {1, 2, 1, 3};
        int n1 = 1312;
        int ret1 = sol.solution(card1, n1);

        System.out.println("Solution: return value of the method is " + ret1 + " .");
        int card2[] = {1, 1, 1, 2};
        int n2 = 1122;
        int ret2 = sol.solution(card2, n2);
        System.out.println("Solution: return value of the method is " + ret2 + " .");
        
    }    
}