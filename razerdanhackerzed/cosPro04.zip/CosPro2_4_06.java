package cosPro04;
class Solution6 {
    public int solution(int point) {
        if (point < 1000)
            return 0;
        return point * 100 / 100;
    }
    
}
class CosPro2_4_06{ 
    public static void main(String[] args) {
        Solution6 sol = new Solution6();
        int point = 2323;
        int ret = sol.solution(point);
        
        System.out.println("solution " + ret + " ?");
    }
}