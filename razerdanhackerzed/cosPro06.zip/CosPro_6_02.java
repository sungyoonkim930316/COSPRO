package cosPro06;
class Solution2 {
    public int solution(int[] papers, int K) {
        int length = papers.length;
        for(int i = 0; i < papers.length; i++){
        	K -= papers[i];
        	if(K < 0)
        		length = i;
        }
        return length;
    }
}
class CosPro06_02{
    public static void main(String[] args) {
    	Solution2 sol = new Solution2();
    	int[] papers1 = {2, 4, 3, 2, 1};
    	int K1 = 10;
    	int ret1 = sol.solution(papers1, K1);

    	System.out.println("solution  " + ret1 + ".");
    	int[] papers2 = {2, 4, 3, 2, 1};
    	int K2 = 14;
    	int ret2 = sol.solution(papers2, K2);
    	System.out.println("solution  " + ret2 + ".");
    }
}