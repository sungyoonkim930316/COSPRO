package cosPro06;
import java.util.*;

class Solution3 {
    public int[] solution(int[] people) {
        int[] answer = new int[4];
        return answer;
    }
}
class CosPro06_03{
	
    public static void main(String[] args) {
        Solution3 sol = new Solution3();
        int[] people = {97, 102, 93, 100, 107};
        int[] ret = sol.solution(people);
        System.out.println("solution  " + Arrays.toString(ret) + ".");
    }
}