package cosPro1_3;
import java.util.*;

class Solution3 {
    public int solution(String[] bishops) {
        int answer = 0;
        return answer;
    }

    public static void main(String[] args) {
        Solution3 sol = new Solution3();
        String[] bishops1 = {new String("D5")};
        int ret1 = sol.solution(bishops1);
        
        System.out.println("Solution: return value of the method is " + ret1 + " .");

        String[] bishops2 = {new String("D5"), new String("E8"), new String("G2")};
        int ret2 = sol.solution(bishops2);
        
        System.out.println("Solution: return value of the method is " + ret2 + " .");
    }
}