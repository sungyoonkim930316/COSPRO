package cosPro1_1;
// You may use import as below.
//import java.util.*;

class Solution1 {
    public long solution(long num) {
        // Write code here.
        long answer = 0;
        return answer;
    }
}
class CosPro1_01{
    // The following is main method to output testcase.
    public static void main(String[] args) {
        Solution1 sol = new Solution1();
        long num = 9949999;
        long ret = sol.solution(num);

        // Press Run button to receive output. 
  
        System.out.println("Solution: return value of the method is " + ret + " .");
    }
}