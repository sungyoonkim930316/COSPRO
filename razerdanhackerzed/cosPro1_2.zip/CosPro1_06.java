package cosPro1_2;
import java.util.*;

class Solution6 {
    public int[] solution(String commands) {
        int[] answer = {};
        return answer;
    }
}
class CosPro1_06{
    public static void main(String[] args) {
        Solution6 sol = new Solution6();
        String commands = "URDDL";
        int[] ret = sol.solution(commands);

        System.out.println("Solution: " + Arrays.toString(ret)  + " .");
    }
}