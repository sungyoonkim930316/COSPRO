package cosPro1_6;
import java.util.*;

class Solution3 {
    public int solution(int[] arr, int K) {
        int answer = 0;
        return answer;
    }

    public static void main(String[] args) {
    	Solution3 sol = new Solution3();
    	int[] arr = {9, 11, 9, 6, 4, 19};
    	int K = 4;
    	int ret = sol.solution(arr, K);
    	
    	System.out.println("Solution: return value of the method is " + ret + " .");

    }
}