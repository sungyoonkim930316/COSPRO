package cosPro1_4;
import java.util.*;

class Solution10 {
    public int solution(int a, int b) {
        int answer = 0;
        return answer;
    }

    public static void main(String[] args){
        Solution10 sol = new Solution10();
        int a = 6;
        int b = 30;
        int ret = sol.solution(a, b);
        System.out.println("Solution: return value of the method is " + ret + " .");
    }
}