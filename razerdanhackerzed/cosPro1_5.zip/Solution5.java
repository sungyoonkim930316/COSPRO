package cosPro1_5;
import java.util.*;

class Solution5 {
    public int solution(int[] enemies, int[] armies) {
        int answer = 0;
        return answer;
    }

    public static void main(String[] args) {
    	Solution5 sol = new Solution5();
    	int[] enemies1 = {1, 4, 3};
    	int[] armies1 = {1, 3};
    	int ret1 = sol.solution(enemies1, armies1);

    	System.out.println("Solution: return value of the method is " + ret1 + " .");
    	int[] enemies2 = {1, 1, 1};
    	int[] armies2 = {1, 2, 3, 4};
    	int ret2 = sol.solution(enemies2, armies2);
    	System.out.println("Solution: return value of the method is " + ret2 + " .");
    }
}