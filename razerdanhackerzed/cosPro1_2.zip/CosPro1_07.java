package cosPro1_2;
class Solution7 {
    public int solution(int money) {
        int coin[] = {10, 50, 100, 500, 1000, 5000, 10000, 50000};
        int counter = 0;
        int idx = coin.length - 1;
        while (money > 0){
//            counter += @@@;
//            money %= @@@;
//            idx -= @@@;
        }
        return counter;
    }
}
class CosPro1_07{
    public static void main(String[] args) {
        Solution7 sol = new Solution7();
        int money = 2760;
        int ret = sol.solution(money);

        System.out.println("Solution: return value of the method is " + ret + " .");
    }
}