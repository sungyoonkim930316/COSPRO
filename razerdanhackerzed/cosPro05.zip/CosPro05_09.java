package cosPro05;
import java.util.*;

class Solution9 {
    public int[] solution(int[] score) {
        int[] answer = {};
        return answer;
    }
}
class CosPro05_09{
    public static void main(String[] args) {
        Solution9 sol = new Solution9();
        int[] score1 = {90, 87, 87, 23, 35, 28, 12, 46};
        int[] ret1 = sol.solution(score1);

        System.out.println("solution " + Arrays.toString(ret1) + " .");

        int[] score2 = {10, 20, 20, 30};
        int[] ret2 = sol.solution(score2);

        System.out.println("solution " + Arrays.toString(ret2) + " .");
    }
}