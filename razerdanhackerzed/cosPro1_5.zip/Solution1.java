package cosPro1_5;
class Solution1 {
    public int solution(int n) {
        int answer = 0;

        int[] steps = new int[n+1];
        steps[1] = 1;
        steps[2] = 2;
        steps[3] = 4;
        for(int i = 4; i <= n; i++) {
        	//steps[i] = @@@;
        }
        answer = steps[n];

        return answer;
    }

    public static void main(String[] args) {
    	Solution1 sol = new Solution1();
    	int n1 = 3;
    	int ret1 = sol.solution(n1);

    	System.out.println("Solution: return value of the method is " + ret1 + " .");

    	int n2 = 4;
    	int ret2 = sol.solution(n2);

    	System.out.println("Solution: return value of the method is " + ret2 + " .");
    }
}