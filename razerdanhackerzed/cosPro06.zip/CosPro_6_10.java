package cosPro06;
class Solution10 {
    public int solution(int weight, int[] boxes) {
        int answer = 0;

//        for(int i = 0; i < boxes.length; i++) 
//        	if(@@@)
//        		answer++;
        	
        return answer;
    }
}

class CosPro06_10{ 
    public static void main(String[] args) {
        Solution10 sol = new Solution10();
        int weight = 600;
        int[] boxes = {653, 670, 533, 540, 660};
        int ret = sol.solution(weight, boxes);
    	System.out.println("solution  " + ret + ".");
    }
}