package cosPro1_3;
import java.util.*;

class Solution4 {
    public int solution(String s1, String s2) {
        int answer = 0;
        return answer;
    }
    
    public static void main(String[] args) {
        Solution4 sol = new Solution4();
        String s1 = new String("ababc");
        String s2 = new String("abcdab");
        int ret = sol.solution(s1, s2);
        System.out.println("Solution: return value of the method is " + ret + " .");
    }
}