package cosPro05;
class Solution1 {
    public int solution(int[][] ladders, int win) {
        int answer = 0;
        
        int[] player = { 1, 2, 3, 4, 5, 6 };
        
        for(int i = 0; i < ladders.length; i++) {
            int temp = player[ladders[i][0]-1];
            //@@@ = @@@;
            //@@@ = temp;
        }
        
        answer = player[win-1];
        
        return answer;
    }
}
class CosPro05_01{

    public static void main(String[] args) {
        Solution1 sol = new Solution1();
        int[][] ladders = {{1, 2}, {3, 4}, {2, 3}, {4, 5}, {5, 6}};
        int win = 3;
        int ret = sol.solution(ladders, win);
        
        System.out.println("solution " + ret + " .");
    }
}