package cosPro1_2;
class Solution10 {
    public String solution(String s) {
        s += '#';
        String answer = "";
        for(int i = 0; i < s.length(); ++i){
            if (s.charAt(i) == '0' && s.charAt(i+1) != '0')
                answer += "0";
            else
                answer += "1";
        }
        return answer;
    }
}
class CosPro1_10{
    public static void main(String[] args) {
        Solution10 sol = new Solution10();
        String s = "101100011100";
        String ret = sol.solution(s);
        System.out.println("Solution: return value of the method is " + ret + " .");
    }
}