package cosPro1_6;
import java.util.*;

class Solution1 {
    public int solution(int n, int[][] garden) {
        int answer = 0;
        return answer;
    }
    
    public static void main(String[] args) {
        Solution1 sol = new Solution1();
        int n1 = 3;
        int[][] garden1 = {{0, 0, 0}, {0, 1, 0}, {0, 0, 0}};
        int ret1 = sol.solution(n1, garden1);
        
        System.out.println("Solution: return value of the method is " + ret1 + " .");

        int n2 = 2;
        int[][] garden2 = {{1, 1}, {1, 1}};
        int ret2 = sol.solution(n2, garden2);
        
        System.out.println("Solution: return value of the method is " + ret2 + " .");
        
    }    
}