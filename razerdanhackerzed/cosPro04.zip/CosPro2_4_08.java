package cosPro04;
import java.util.*;

class Solution8 {
    public int solution(int n, int[] votes) {
        int[] arr = new int[n+1];
        for(int i=0; i<votes.length; i++) {
            arr[votes[i]]++;
        }
        for(int i=1; i<n+1; i++)
            if(arr[i] > n/2)
                return i;
        return -1;
    }
}
class CosPro2_4_08{ 
    public static void main(String[] args) {
        Solution8 sol = new Solution8();
        int n1 = 3;
        int[] votes1 = {1, 2, 1, 3, 1, 2, 1};
        int ret1 = sol.solution(n1, votes1);

        System.out.println("solution" + ret1 + ".");
        
        int n2 = 2;
        int[] votes2 = {2, 1, 2, 1, 2, 2, 1};
        int ret2 = sol.solution(n2, votes2);

        System.out.println("solution" + ret2 + ".");     
    }    
}