package cosPro1_6;
import java.util.*;

class Solution2 {
    public int solution(int K, String[] words) {
        int answer = 0;
        return answer;
    }

    public static void main(String[] args) {
        Solution2 sol = new Solution2();
        int K = 10;
        String[] words = {new String("nice"), new String("happy"), new String("hello"), new String("world"), new String("hi")};
        int ret = sol.solution(K, words);

        System.out.println("Solution: return value of the method is " + ret + " .");

    }
    
}