package cosPro06;
class Solution1 {
	public int solution(int[] temperature, int A, int B) {
		int answer = 0;
		for(int i = 0; i < temperature.length; i++) {
			if(temperature[i] > temperature[A] && temperature[i] > temperature[B])
				answer += 1;
		}
		return answer;
	}
}
class CosPro06_01{
	public static void main(String[] args) {
		Solution1 sol = new Solution1();
		int[] temperature = {3, 2, 1, 5, 4, 3, 3, 2};
		int A = 1;
		int B = 6;
		int ret = sol.solution(temperature, A, B);

		System.out.println("solution  " + ret + ".");
	}
}