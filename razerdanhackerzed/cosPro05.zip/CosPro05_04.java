package cosPro05;
class Solution4 {
    public int solution(int taekwondo, int running, int[] shooting) {
        int answer = 0;

        if(taekwondo >= 25) {
            //answer += @@@;
        }
        else {
            answer += taekwondo * 8;
        }
        answer += 250 + (60 - running) * 5;

        int count = 0;
        for(int i = 0; i < shooting.length; i++) {
            answer += shooting[i];
            if(shooting[i] == 10)
                count++;
        }
        if(count >= 7) {
            //answer += @@@;
        	}

		return answer;
    }

}
class CosPro05_04{
    public static void main(String[] args) {
    	Solution4 sol = new Solution4();
    	int taekwondo = 27;
    	int running = 63;
    	int[] shooting = {9, 10, 8, 10, 10, 10, 7, 10, 10, 10};
    	int ret = sol.solution(taekwondo, running, shooting);
    	  System.out.println("solution " + ret + " .");
    }
}