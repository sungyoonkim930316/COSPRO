package cosPro1_4;
import java.util.*;

class Solution9 {
    public String solution(int hour, int minute) {
        String answer = "";
        return answer;
    }

    public static void main(String[] args) {
        Solution9 sol = new Solution9();
        int hour = 3;
        int minute = 0;
        String ret = sol.solution(hour, minute);
        System.out.println("Solution: return value of the method is " + ret + " .");
    }
}