package cosPro06;
class Solution5 {
    public int solution(int money, int price, int n) {
        int answer = 0;

        int emptyBottle = answer = money / price;
        while(n <= emptyBottle) {
        	emptyBottle = emptyBottle - n;
        	answer++;
        	emptyBottle++;
        }
        
        return answer;
    }
}
class CosPro06_05{
	
    public static void main(String[] args) {
    	Solution5 sol = new Solution5();
    	int money1 = 8;
    	int price1 = 2;
    	int n1 = 4;
    	int ret1 = sol.solution(money1, price1, n1);

    	System.out.println("solution 메소?��?�� 반환 값�? " + ret1 + " ?��?��?��.");

    	int money2 = 6;
    	int price2 = 2;
    	int n2 = 2;
    	int ret2 = sol.solution(money2, price2, n2);

    	System.out.println("solution 메소?��?�� 반환 값�? " + ret2 + " ?��?��?��.");
    }
}