package cosPro1_5;
import java.util.*;

class Solution9 {
	public int solution(int number, int target) {
		int answer = 0;
		return answer;
	}

	public static void main(String[] args) {
		Solution9 sol = new Solution9();
		int number1 = 5;
		int target1 = 9;
		int ret1 = sol.solution(number1, target1);

		System.out.println("Solution: return value of the method is " + ret1 + " .");
		int number2 = 3;
		int target2 = 11;
		int ret2 = sol.solution(number2, target2);
		System.out.println("Solution: return value of the method is " + ret2 + " .");
	}
}