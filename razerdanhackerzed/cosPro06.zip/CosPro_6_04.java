package cosPro06;
import java.util.*;

class Solution4 {
    public int solution(String[][] cards) {
        int answer = 0;
        return answer;
    }
}
class CosPro_6_04{
	
    public static void main(String[] args) {
    	Solution4 sol = new Solution4();
        String[][] cards1 = {{new String("blue"), new String("2")}, {new String("red"), new String("5")}, {new String("black"), new String("3")}};
        int ret1 = sol.solution(cards1);
    	System.out.println("solution  " + ret1 + ".");

        String[][] cards2 = {{new String("blue"), new String("2")}, {new String("blue"), new String("5")}, {new String("black"), new String("3")}};
        int ret2 = sol.solution(cards2);
    	System.out.println("solution  " + ret2 + ".");
    }
}