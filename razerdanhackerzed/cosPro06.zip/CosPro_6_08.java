package cosPro06;
class Solution8 {
	public int func_a(int number1, int number2) {
		int ret = 0;

		if(number1 > number2)
			ret = number1 - number2;
		else
			ret = number2 - number1;

		return ret;
	}

	public int func_b(int number) {
		int ret = 0;

		while(number != 0) {
			number = number / 10;
			ret++;
		}

		return ret;
	}

	public int func_c(int number, int digit) {
		int ret = 0;

		for(int i = 0; i < digit; i++) {
			int temp = number % 10;
			number = number / 10;
			ret = ret * 10 + temp;
		}

		return ret;
	}

	public int solution(int number) {
		int answer = 0;
//		int digit = func_@@@(@@@);
//		int convert_number = func_@@@(@@@);
//		answer = func_@@@(@@@);
		return answer;
	}
}

class CosPro06_08{
	
	public static void main(String[] args) {
		Solution8 sol = new Solution8();
		int number1 = 120;
		int ret1 = sol.solution(number1);
		System.out.println("solution  " + ret1 + ".");
		int number2 = 23;
		int ret2 = sol.solution(number2);
		System.out.println("solution  " + ret2 + ".");
	}
}