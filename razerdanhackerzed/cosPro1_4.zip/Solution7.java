package cosPro1_4;
import java.util.Arrays;

class Solution7 {
    class Unit {
        public int HP;
        public Unit() {
            this.HP = 1000;
        }
        public void underAttack(int damage) { }
    }

//    class Monster @@@ {
//        public int attackPoint;
//        public Monster(int attackPoint) {
//            this.attackPoint = attackPoint;
//        }
//        @@@ {
//            this.HP -= damage;
//        }
//        @@@ {
//            return attackPoint;
//        }
//    }
//
//    class Warrior @@@ {
//        public int attackPoint;
//        public Warrior(int attackPoint) {
//            this.attackPoint = attackPoint;
//        }
//        @@@ {
//            this.HP -= damage;
//        }
//        @@@ {
//            return attackPoint;
//        }
//    }
//
//    class Healer @@@ {
//        public int healingPoint;
//        public Healer(int healingPoint) { 
//            this.healingPoint = healingPoint;
//        }
//        @@@ {
//            this.HP -= damage;
//        }
//        @@@ {
//            unit.HP += healingPoint;
//        }
//    }
    public int[] solution(int monsterAttackPoint, int warriorAttackPoint, int healingPoint) {
//        Monster monster = new Monster(monsterAttackPoint);
//        Warrior warrior = new Warrior(warriorAttackPoint);
//        Healer healer = new Healer(healingPoint);
//        
//        monster.underAttack(warrior.attack());
//        warrior.underAttack(monster.attack());
//        healer.underAttack(monster.attack());
//        healer.healing(warrior);
//        healer.healing(monster);
//
//        int[] answer = {monster.HP, warrior.HP, healer.HP};
        return null; // answer;
    }

    public static void main(String[] args) {
        Solution7 sol = new Solution7();
        int monsterAttackPoint = 100;
        int warriorAttackPoint = 90;
        int healingPoint = 30;
        int[] ret = sol.solution(monsterAttackPoint, warriorAttackPoint, healingPoint);

        System.out.printf("solution : ");
        System.out.printf(Arrays.toString(ret));
   
    }   
}