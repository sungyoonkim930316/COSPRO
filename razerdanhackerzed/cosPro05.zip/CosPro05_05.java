package cosPro05;
class Solution {
    public int solution(int a, int b) {
        int answer = 0;
        
        for(int i = 1; i <= b; i++) {
            if((a * i) % b == 0) {
                answer = b * i;
                break;
            }
        }
        
        return answer;
    }

}
class CosPro05_05{
    public static void main(String[] args) {
        Solution sol = new Solution();
        int a = 4;
        int b = 6;
        int ret = sol.solution(a, b);
        System.out.println("solution " + ret + " .");
    }
}