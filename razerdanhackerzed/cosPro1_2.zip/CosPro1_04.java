package cosPro1_2;
import java.util.*;

class Solution4 {
    public int solution(int[] arr, int K) {
        int answer = 0;
        return answer;
    }
}
class CosPro1_04{
    public static void main(String[] args) {
        Solution4 sol = new Solution4();
        int[] arr = {1, 2, 3, 4, 5};
        int K = 3;
        int ret = sol.solution(arr, K);

        System.out.println("Solution: return value of the method is " + ret + " .");
    }
}