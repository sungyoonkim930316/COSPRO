package cosPro04;
import java.util.*;

class Solution5 {
    public int solution(int[] calorie) {
        int minCal = 0;
        int answer = 0;
        for(int i=0; i<calorie.length; i++) {
            if(calorie[i] > minCal)
                answer += calorie[i] - minCal;
            else
                minCal = calorie[i];
        }
        return answer;
    }
}
class CosPro2_4_05{ 
    public static void main(String[] args) {
        Solution5 sol = new Solution5();
        int[] calorie = {713, 665, 873, 500, 751};
        int ret = sol.solution(calorie);
        
        System.out.println("solution " + ret + " ");
    }
}