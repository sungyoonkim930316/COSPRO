package cosPro04;
import java.util.*;

class Solution9 {
    public int solution(int[][] height) {
        int count = 0;
        return count;
    }

}
class CosPro2_4_09{ 
    public static void main(String[] args) {
        Solution9 sol = new Solution9();
        int[][] height = {{3, 6, 2, 8}, {7, 3, 4, 2}, {8, 6, 7, 3}, {5, 3, 2, 9}};
        int ret = sol.solution(height);

        System.out.println("solution " + ret + " .");
    }
}