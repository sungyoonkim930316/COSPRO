package cosPro06;
class Solution7 {
    public int solution(int money, int[] chairs, int[] desks) {
        int answer = 0;

        for(int i = 0; i < chairs.length; i++) {
            for(int j = 0; j < desks.length; j++) {
                //int price = @@@;
               // if(answer < price && @@@)
                //    answer = price;
            }
        }

        return answer;
    }
}

class CosPro06_07{
	
    public static void main(String[] args) {
        Solution7 sol = new Solution7();
        int money1 = 7;
        int[] chairs1 = {2, 5};
        int[] desks1 = {4, 3, 5};
        int ret1 = sol.solution(money1, chairs1, desks1);
    	System.out.println("solution  " + ret1 + ".");

        int money2 = 7;
        int[] chairs2 = {3};
        int[] desks2 = {5};
        int ret2 = sol.solution(money2, chairs2, desks2);
    	System.out.println("solution  " + ret2 + ".");
    }
}