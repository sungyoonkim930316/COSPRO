package cosPro1_4;
class Solution5 {
    public String reverse(String number) {
        String reverseNumber = "";
        for(int i = number.length()-1; i >= 0; i--) {
          //  @@@;
        }
        return reverseNumber;
    }

    public String solution(int n) {
        String answer = "";
        for(int i = 0; i < n; i++) {
          //  answer += Integer.toString(@@@);
            answer = reverse(answer);
        }
        return answer;
    }

    public static void main(String[] args) {
        Solution5 sol = new Solution5();
        int n = 5;
        String ret = sol.solution(n);
        System.out.println("Solution: return value of the method is " + ret+ " .");
    }
}