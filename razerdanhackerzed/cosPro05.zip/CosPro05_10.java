package cosPro05;
import java.util.*;

class Solution10 {
    public int solution(int[] timeTable, int n) {
        int answer = 0;
        return answer;
    }
} 
    class CosPro05_10{
    public static void main(String[] args) {
    	Solution10 sol = new Solution10();
    	int[] timeTable1 = {1, 5, 1, 9};
    	int n1 = 3;
    	int ret1 = sol.solution(timeTable1, n1);
    	  System.out.println("solution " + ret1 + " .");

    	int[] timeTable2 = {4, 8, 2, 5, 4, 6, 7};
    	int n2 = 4;
    	int ret2 = sol.solution(timeTable2, n2);
    	  System.out.println("solution " + ret2 + " .");
    }
}