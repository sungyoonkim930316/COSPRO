package cosPro1_3;
import java.util.ArrayList;

class Solution6 {
    public int solution(int n) {
        int answer = 0;
        ArrayList<Integer> primes = new ArrayList<Integer>();
        primes.add(2);
        for (int i = 3; i <= n; i += 2) {
            boolean isPrime = true;
            for (int j = 2; j < i; j++)
                if (i % j == 0){
                    isPrime = false;
                    break;
                }
           // if (@@@)
            //    primes.add(i);
        }
        
        int primeLen = primes.size();
        for (int i = 0; i < primeLen - 2; i++) {
            for (int j = i + 1; j < primeLen - 1; j++) {
                for (int k = j + 1; k < primeLen; k++) {
                   // if (@@@)
                   //     answer++;
                  }
                }
            }
        return answer;
    }
    
    public static void main(String[] args) {
    	Solution6 sol = new Solution6();
        int n1 = 33;
        int ret1 = sol.solution(n1);

        System.out.println("Solution: return value of the method is " + ret1 + " .");
        int n2 = 9;
        int ret2 = sol.solution(n2);
        System.out.println("Solution: return value of the method is " + ret2 + " .");
    }       
}